#ifndef _PARA_H
#define _PARA_H


#define RUN_ADDR_BASE				                                  0x00								//������ʼ����־λ������ÿ���ϵ綼дEEPROMP
#define SLAVE_ADDR					(RUN_ADDR_BASE		+ 0x01)//�ӻ���ַ
#define DETECT_MODE                                     (SLAVE_ADDR             + 0x01)//��ⷽʽ
#define WAVE_CAL_NUM                                    (DETECT_MODE            + 0x01)
#define WAVE_CAL_TIM                                    (WAVE_CAL_NUM           + 0x01)
#define SMOO_PARA                                       (WAVE_CAL_TIM           + 0x01) 
#define STA_VARY_DURATION                               (SMOO_PARA              + 0x01)//״��仯����ʱ��
#define DETECT_THR                                      (STA_VARY_DURATION      + 0x01)//��ֵ    
#define USER_DEFAULT_LEN				(DETECT_THR             + 0x02)             

//---------------------------------------------------
#define COMPANY						(USER_DEFAULT_LEN       + 0x40) 
#define DEV_ENCODING				        (COMPANY		+ 0x40)
#define HWVERSION					(DEV_ENCODING		+ 0x40)
#define SFVERSION					(HWVERSION	        + 0x40)
#define DEV_ID						(SFVERSION		+ 0x40)
#define CUSTOMERCODE                                    (DEV_ID		        + 0x40)  


void ReadPara(void);


#endif