#ifndef _TIM_H
#define _TIM_H


#include "stm32l0xx.h"
#include "stm32l031xx.h"

void TIM2_Init(void);


#endif