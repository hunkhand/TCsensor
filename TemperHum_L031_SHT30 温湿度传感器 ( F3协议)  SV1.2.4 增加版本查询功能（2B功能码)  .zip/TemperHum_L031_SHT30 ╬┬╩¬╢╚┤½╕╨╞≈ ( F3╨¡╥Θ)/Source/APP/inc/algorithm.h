#ifndef _ALGORITHM_H
#define _ALGORITHM_H


#include "stm32l0xx.h"


int GetDelExtremeAndAverage(int Array[], const uint32_t ArraySize, const uint32_t SortHeadSize, const uint32_t SortTailSize);

#endif