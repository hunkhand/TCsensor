//#include "BSP.h"
#include "TH_IIC.h"


uint8_t x, y1, y2;


void Delay_Us(uint32_t cnt)
{
    cnt = cnt;      //�����2,50�����ϻ���Ϊ0�ȣ����Ϊ4��������¶�
    while (cnt--);      //16M����Ƶ����ʱҪ�޸�
}

void Delay_Ms(uint32_t cnt)
{
    cnt = cnt * 940;

    while (cnt--);
   
  
}



/*******************************************************************************
// ����         : Get_GPIO_PIN
// ��������     : 2017-07-29
// ����         : ÷����
// ����         : ͨ��ͨ���Ż�ö�Ӧ��GPIO��PIN
// �������     : ��
// �������     : ��
// ���ؽ��     : ��
// ע���˵��   : ͨ����0-PA12;1-PA5;2-PB3;3-PB4
// �޸�����     : 
********************************************************************************/
void Get_Channal_Pin(uint8_t sChannel)
{
    switch(sChannel)
    {     
    case 0:
        x = 0;
        y1 = 9;
        y2 = 10;
        break;
        
    case 1:
        x = 1;
        y1 = 3;
        y2 = 4;
        break; 
        
    case 2:
        x = 1;
        y1 = 5;
        y2 = 12;
        break;

    case 3:
        x = 1;
        y1 =13;
        y2 = 14;
        break ;
        
    default:
        break;
    }
}



//******************************************************************************
// ����         : IIC_Init()
// ��������     : 2017-11-07
// ����         : IIC GPIO����
// �������     : ��
// �������     : ��
// ���ؽ��     : ��
// ע���˵��   : 
// �޸�����     :
//******************************************************************************
void TH_IIC_Init(void)
{
    //GPIO_InitTypeDef GPIO_InitStructure;
    
    SET_BIT(RCC->APB1ENR, (RCC_APB1ENR_I2C1EN));                             //��I2Cʱ�� 
 /*     //RCC_AHBPeriphClockCmd(PORT_CLOCK(0) | PORT_CLOCK(1), ENABLE);
    GPIO_InitStructure.Pin = P(9) | P(10);
    GPIO_InitStructure.Mode = GPIO_MODE_AF_OD ;
    GPIO_InitStructure.Speed = GPIO_SPEED_FREQ_HIGH;
    //GPIO_InitStructure.GPIO_OType = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStructure.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(G(0), &GPIO_InitStructure);
    
    //GPIO_InitStructure.Pin = P(3) | P(4) | P(5) | P(12) | P(13) | P(14);
    //GPIO_Init(G(1), &GPIO_InitStructure);

    G(0)->BSRR = P(9) | P(10);
    //G(1)->BSRR = P(3) | P(4) | P(5) | P(12) | P(13) | P(14);  
    
  */
    GPIOA->MODER &= 0xFFF3FFFF;            
    GPIOA->MODER |= 0x00040000;           //PA9ͨ�����ģʽ
    GPIOA->OTYPER &= ~(1<<9);             //�������
    GPIOA->OSPEEDR |= (3<<18);            //����  
    GPIOA->PUPDR &= 0xFFF3FFFF;           //����
    GPIOA->PUPDR |= 0x00040000;  
    GPIOA->BRR = GPIO_PIN_9;            //���������ߣ����ֹ���ʱ��λһ������
    Delay_Us(10000);
    GPIOA->BSRR = GPIO_PIN_9;
    
    GPIOA->MODER &= 0xFFCFFFFF;            
    GPIOA->MODER |= 0x00100000;           //PA10ͨ�����ģʽ
    GPIOA->OTYPER &= ~(1<<10);             //�������
    GPIOA->OSPEEDR |= (3<<20);            //����  
    GPIOA->PUPDR &= 0xFFCFFFFF;           //����
    GPIOA->PUPDR |= 0x00100000; 
    GPIOA->BRR = GPIO_PIN_10;
    Delay_Us(10000);
    GPIOA->BSRR = GPIO_PIN_10;

}



void TH_IIC_Start(void)
{
    SDA_I2C_OUT;     
    SDA_I2C_H; 
    SCL_I2C_H;
    Delay_Us(4);
    SDA_I2C_L;
    Delay_Us(4);
    SCL_I2C_L;
}


void TH_IIC_Stop(void)
{
    SDA_I2C_OUT;
    SCL_I2C_L;
    SDA_I2C_L; 
    Delay_Us(4);
    SCL_I2C_H;    
    SDA_I2C_H;
    Delay_Us(4);
}


uint8_t TH_IIC_Wait_Ack(void)
{
    uint8_t ucErrTime = 0;
    SDA_I2C_IN;     
    SDA_I2C_H;
    Delay_Us(1);
    SCL_I2C_H;
    Delay_Us(1);
    while(SDA_I2C_READ)
    {
        if (ucErrTime++ > 250)
        {
            TH_IIC_Stop();
            return 1;
        }
    }
    SCL_I2C_L;
    return 0;
}


void TH_IIC_Ack(void)
{
    SCL_I2C_L;
    SDA_I2C_OUT;
    SDA_I2C_L
    Delay_Us(2);
    SCL_I2C_H;
    Delay_Us(2);
    SCL_I2C_L;
}


void TH_IIC_NAck(void)
{
    SCL_I2C_L;
    SDA_I2C_OUT;
    SDA_I2C_H;
    Delay_Us(2);
    SCL_I2C_H;
    Delay_Us(2);
    SCL_I2C_L;
}


void TH_IIC_Send_Byte(uint8_t txd)
{
    uint8_t t;
    SDA_I2C_OUT;
    SCL_I2C_L;
    for (t = 0; t < 8; t++)
    {
        if(txd & 0x80)
        {
            SDA_I2C_H;
        }
        else
        {
            SDA_I2C_L; 
        }
        txd <<= 1;
        Delay_Us(2);   
        SCL_I2C_H;
        Delay_Us(2);
        SCL_I2C_L;
        Delay_Us(2);
    }
}


uint8_t TH_IIC_Read_Byte(uint8_t ack)
{
    uint8_t i, receive = 0;
    SDA_I2C_IN;

    for (i = 0; i < 8; i++)
    {
        SCL_I2C_L;
        Delay_Us(2);
        SCL_I2C_H;
        receive <<= 1;
        if(SDA_I2C_READ)
            receive++;
        Delay_Us(1);
    }

    if (!ack)
        TH_IIC_NAck();
    else
        TH_IIC_Ack(); 
    return receive;
}

