#ifndef __NVIC_H
#define __NVIC_H
#include "bsp.h"

void NVIC_UARTConfiguration(void);
void NVIC_Timer7Configuration(void);
void NVIC_I2CConfiguration(void);


#endif
