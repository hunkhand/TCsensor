#ifndef _BSP_H_
#define _BSP_H_

//#include "stm32f0xx.h"
#include "stm32l0xx.h"
//#include "Bsp_init.h"
#include "nvic.h"
//#include "delay.h"
#include "usart.h"
//#include "led.h"
//#include "OilStat.h"
#include "SoftwareIIC.h"
#include "TH_IIC.h"
#include "SHT3x.h"

#include "AT24Cxx.h"
#include "modbus_ascii.h"
#include "modbus.h"
#include "modbus_asc.h"
#include "ReadTH.h"
//#include "dma.h"
#include "type.h"
#include "algorithm.h"
#include "Displaystatue.h"
#include "sys_cfg.h"

#include  <includes.h>

extern UartCommTypeDef UartComm;
extern RunVarTypeDef RunVar;
extern ProductParaTypeDef ProductPara;
extern UserParamTypeDef UserParam;
extern u8 Cur_Param[USER_DEFAULT_LEN];

//void Dev_Init();

#endif
