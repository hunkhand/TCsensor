#ifndef __AT24CXX_H__
#define __AT24CXX_H__

//---------------------------------------------------
#define RUN_ADDR_BASE				                                  0x00								//������ʼ����־λ������ÿ���ϵ綼дEEPROMP
#define SLAVE_ADDR					(RUN_ADDR_BASE		+ 0x01)
#define BAUDRATE					(SLAVE_ADDR		+ 0x01)
#define PARITY						(BAUDRATE		+ 0x01)
#define OUTPUT_MODE					(PARITY	                + 0x01)
#define USER_FLOW_K					(OUTPUT_MODE		+ 0x01)
#define USER_FLOW_B					(USER_FLOW_K		+ 0x04)
#define AUTO_UPLOAD_TIME			        (USER_FLOW_B		+ 0x04)
#define ECHOEN						(AUTO_UPLOAD_TIME	+ 0x01)
#define TEM1_UP_THR                                     (ECHOEN                 + 0x01) //�¶�1�Ϸ�ֵ
#define TEM1_DO_THR                                     (TEM1_UP_THR            + 0x02) //�¶�1�·�ֵ
#define TEM2_UP_THR                                     (TEM1_DO_THR            + 0x02) //�¶�2�Ϸ�ֵ
#define TEM2_DO_THR                                     (TEM2_UP_THR            + 0x02) //�¶�2�·�ֵ
#define TEM3_UP_THR                                     (TEM2_DO_THR            + 0x02) //�¶�3�Ϸ�ֵ
#define TEM3_DO_THR                                     (TEM3_UP_THR            + 0x02) //�¶�3�·�ֵ
#define TEM4_UP_THR                                     (TEM3_DO_THR            + 0x02) //�¶�4�Ϸ�ֵ
#define TEM4_DO_THR                                     (TEM4_UP_THR            + 0x02) //�¶�4�·�ֵ
#define HUM1_UP_THR                                     (TEM4_DO_THR            + 0x02) //ʪ��1�Ϸ�ֵ
#define HUM1_DO_THR                                     (HUM1_UP_THR            + 0x02) //ʪ��1�·�ֵ
#define HUM2_UP_THR                                     (HUM1_DO_THR            + 0x02) //ʪ��2�Ϸ�ֵ
#define HUM2_DO_THR                                     (HUM2_UP_THR            + 0x02) //ʪ��2�·�ֵ
#define HUM3_UP_THR                                     (HUM2_DO_THR            + 0x02) //ʪ��3�Ϸ�ֵ
#define HUM3_DO_THR                                     (HUM3_UP_THR            + 0x02) //ʪ��3�·�ֵ
#define HUM4_UP_THR                                     (HUM3_DO_THR            + 0x02) //ʪ��4�Ϸ�ֵ
#define HUM4_DO_THR                                     (HUM4_UP_THR            + 0x02) //ʪ��4�·�ֵ
#define USER_DEFAULT_LEN			        (HUM4_DO_THR     	+ 0x02)
//---------------------------------------------------

//---------------------------------------------------
#define USER_DEFAULT_PARA_BAK1		                (RUN_ADDR_BASE	 	        + 0x80)
#define USER_DEFAULT_PARA_BAK2		                (USER_DEFAULT_PARA_BAK1 	+ 0x80)

//---------------------------------------------------
#define COMPANY						(USER_DEFAULT_PARA_BAK2         + 0x80)
#define DEV_ENCODING				        (COMPANY		        + 0x40)
#define HWVERSION					(DEV_ENCODING		        + 0x40)
#define SFVERSION					(HWVERSION		        + 0x40)
#define DEV_ID						(SFVERSION		        + 0x40)
#define CUSTOMERCODE                                    (DEV_ID		                + 0x40)
//---------------------------------------------------




#define AT24C01			127
#define AT24C02			255
#define AT24C04			511
#define AT24C08			1023
#define AT24C16			2047
#define AT24C32			4095
#define AT24C64	    	        8191
#define AT24C128		16383
#define AT24C256		32767
#define EE_TYPE			AT24C16

#define EEPROM_ADDRESS          0xA0

u8 I2C1_ReadByte(u16 DriverAddr, u16 ReadAddr);							//ָ����ַ��ȡһ���ֽ�
void I2C1_WriteByte(uint16_t DriverAddr, u16 WriteAddr, u8 DataToWrite);		//ָ����ַд��һ���ֽ�
void I2C1_WriteLenByte(uint16_t DriverAddr, u16 WriteAddr, u32 DataToWrite, u8 Len);  //ָ����ַ��ʼд��ָ�����ȵ�����
u32 I2C1_ReadLenByte(uint16_t DriverAddr, u16 ReadAddr, u8 Len);					//ָ����ַ��ʼ��ȡָ����������
void I2C1_WriteNBytes(uint16_t DriverAddr, u16 WriteAddr, u16 NumToWrite, const u8 *pBuffer);   	//��ָ����ַ��ʼ����ָ�����ȵ�����
void I2C1_WNBytesMul3T(uint16_t DriverAddr, u16 WriteAddr, u16 NumToWrite, const u8 *pBuffer);
void I2C1_ReadNBytes(u16 DriverAddr, u16 ReadAddr, u16 NumToRead, u8 *pBuffer);					//��ָ����ַ��ʼд��ָ�����ȵ�����

u8 AT24CXX_Check(uint16_t DriverAddr);    //�������
void AT24CXX_Init(void);   //��ʼ��IIC

void EEProm_Init(void);
float Switch_Expansion(u8 *Expansion);
u8 AutoUpLoadTimeTransform(u8 CodeValue);
void Rd_Dev_Param(void);


#endif
