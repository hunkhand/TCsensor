#ifndef _TIMER_H_
#define _TIMER_H_

#define SENSOR_MOUNT_SINGLE     0
#define SENSOR_MOUNT_DOUBLE     1


void Capture_TimerInit(void);
void Save_Param(u32 saveFlg);
extern ProductParaTypeDef ProductPara;

float Freq_CalcuFactor(float Frequence, float *pFreq, float *pFactor, u32 num);

#endif

